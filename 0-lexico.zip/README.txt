Instruções para compilação:

1 - Abra um terminal
2 - Execute o comando make

Obs: Certifique-se que a pasta bin existe na pasta raiz

Instruções para execução:

1 - Execute o pograma 'lexico'